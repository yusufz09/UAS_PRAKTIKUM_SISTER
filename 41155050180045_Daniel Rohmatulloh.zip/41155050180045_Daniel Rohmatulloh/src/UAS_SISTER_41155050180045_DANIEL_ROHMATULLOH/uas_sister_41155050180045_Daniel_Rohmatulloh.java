package UAS_SISTER_41155050180045_DANIEL_ROHMATULLOH;

import static java.lang.Thread.sleep;
import java.io.IOException;
import java.util.Scanner;

public class uas_sister_41155050180045_Daniel_Rohmatulloh extends Thread {
    
    int threadNumber; //deklarasi threadnumber
    int time; //deklarasi time global
    
    public uas_sister_41155050180045_Daniel_Rohmatulloh(int TNo, int t) {
        threadNumber = TNo; //inisialisasi threadnumber global
        time = t; //inisialisasi time global
    }
    public void run() {
        int count = 1; //variabel count diberi nilai 1
        System.out.println("\nThread No : "+threadNumber);
        try {
            for (int i = 1; i <= this.time; i++) { //perulangan pada threadnumber
                Thread.sleep(1000); //sleep selama 1000ms/ 1 detik jadi menyesuaikan dengan jumlah waktu
                System.out.print("Thread "+threadNumber+"."+i+", ");
            }
        } catch (Exception e) {
            System.out.println("Thread No " + threadNumber + " Berakhir");            
        }
        System.out.println("\nThread No " + threadNumber + " Berakhir");

    }

    public static void main(String[] args) throws IOException, InterruptedException {
        
        boolean putaran = true;  //deklarasi pengulangan
        int thread = 0;  //deklarasi jumlah thread diberi nilai 0 dari awal
        int time = 0;  //deklarasi waktu diberi nilai 0 dari awal
        Thread thr = null; //deklarasi thread dengan nilai null
        Scanner input = new Scanner(System.in); //inisialisasi scanner
        do {
            System.out.println("<========== Multithread Programming ==========>\n");
            System.out.print("Masukan jumlah thread  : ");
            thread = input.nextInt(); //masukan jumlah thread
            System.out.print("Masukan waktu (second) : ");
            time = input.nextInt(); //masukan waktu dalam satuan detik
            input.nextLine(); 
            System.out.print("Mulai ulang setelah selesai ? ");
            String text = input.nextLine(); //masukan text "ya" atau "tidak"
            putaran = (text.equals("Ya") ? true : false); //jika Ya maka ulangi
            System.out.println("");
            System.out.println("Mulai Proses Multithread...");
            for (int i = 1; i <= thread; i++) { //ulangi sebanyak jumlah thread
                thr = new uas_sister_41155050180045_Daniel_Rohmatulloh(i, time);  //inisialisasi thread
                thr.start(); //mulai thread
                thr.join(); //Menunggu thred sebelumnya selesai, baru thread selanjutnya untuk memulai
            }
        }while(putaran && !thr.isAlive()); //megulangi jika thread nya udah mati dan ulang nya true
        System.out.println("\nThread Berhasil Dijalankan");
    }
}
